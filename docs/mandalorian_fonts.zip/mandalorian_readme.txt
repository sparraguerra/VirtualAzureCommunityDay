Mandalorian
Windows & Macintosh TrueType Font
Created by ErikStormtrooper.com

----------------------------------------------------------

FONT INFORMATION

This Star Wars font is based on samples of Mandalorian 
seen in the Episode II Visual Dictionary as well as menu 
screens from the 2004 DVD release of Star Wars. This font
includes all English letters, numbers, and common 
punctuation marks (basically, all the stuff displayed on 
the keyboard). Uppercase and lowercase letters are 
identical. Also, kerning has been enabled for this font. 
See mandalorian_table.jpg for a full table of Mandalorian
letters and their respective keys. 

----------------------------------------------------------

ACCURACY OF THIS FONT

My main source for this font is a menu screen taken from
the 2004 release of the Star Wars DVDs. Unfortunately, 
there were some letters and numbers that were not present:
m, p, q, v, x, z, 1, 2, and 0. There was also no 
punctuation. In order to fill in the gaps, I used what I 
had as an inspiration for the rest. Because of that, I'd
say this font is only 75% accurate. 

Is it Really Mandalorian? Yes. In the Episode II Visual 
Dictionary, there's a small readout of the technical 
display from the Slave I. Check it out, and you can 
clearly see the similarity between it and the alphabet 
that appears on the DVD. 
 
----------------------------------------------------------

LEGAL MUMBO JUMBO

This font is not officially licensed and is not intended 
to infringe on any copyright. This font is freeware; it 
may be distributed freely, but PLEASE distribute all files
included in the ZIP archive. This font is NOT to be sold 
or used for financial gain. Help keep it free and 
available!
